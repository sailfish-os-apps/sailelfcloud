elfcloud-weasel
======================

elfCLOUD.fi Weasel Library and Command Line Interface Tool
