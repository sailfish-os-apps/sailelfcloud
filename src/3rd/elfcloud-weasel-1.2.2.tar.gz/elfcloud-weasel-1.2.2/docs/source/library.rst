*************************************************
API documentation
*************************************************

Client
======
.. automodule:: elfcloud.client
    :members:

Connection
==========
.. automodule:: elfcloud.connection
    :members:

Container
=========
.. automodule:: elfcloud.container
    :members:

DataItem
========
.. automodule:: elfcloud.dataitem
    :members:

FileCrypt
=========
.. automodule:: elfcloud.filecrypt
    :members:
